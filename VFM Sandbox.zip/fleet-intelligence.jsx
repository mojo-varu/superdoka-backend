/* Fleet Intelligence — Owner view, neobrutalism */

const FLEET_LOGS = [
  { time: "07:02", op: "ИС", opColor: "var(--nb-bg-alt)", opName: "Иван Сидоров", machine: "CAT-101", raw: "Начинаю смену на CAT-101", intent: "shift_start", tags: [["shift_start", "lime"]], conf: "97%", severity: null, ext: { Intent: "shift_start", Machine: "CAT-101", Conf: "97%" } },
  { time: "07:10", op: "ПК", opColor: "var(--nb-bg-alt)", opName: "Пётр Кузнецов", machine: "BLZ-042", raw: "Начинаю смену на BLZ-042", intent: "shift_start", tags: [["shift_start", "lime"]], conf: "97%", severity: null, ext: { Intent: "shift_start", Machine: "BLZ-042", Conf: "97%" } },
  { time: "07:30", op: "МФ", opColor: "var(--nb-bg-alt)", opName: "Михаил Фёдоров", machine: "KOM-007", raw: "начинаю KOM-007", intent: "shift_start", tags: [["shift_start", "lime"]], conf: "95%", severity: null, ext: { Intent: "shift_start", Machine: "KOM-007", Conf: "95%" } },
  { time: "08:00", op: "ПК", opColor: "var(--nb-bg-alt)", opName: "Пётр Кузнецов", machine: "BLZ-042", raw: "Залил 80л солярки", intent: "fuel_log", tags: [["fuel_log", "sky"], ["80л", "ink"]], conf: "93%", severity: null, ext: { Intent: "fuel_log", Volume: "80л", Conf: "93%" } },
  { time: "08:15", op: "ИС", opColor: "var(--nb-bg-alt)", opName: "Иван Сидоров", machine: "CAT-101", raw: "Залил 150 литров", intent: "fuel_log", tags: [["fuel_log", "sky"], ["150л", "ink"]], conf: "96%", severity: null, ext: { Intent: "fuel_log", Volume: "150л", Conf: "96%" } },
  { time: "09:30", op: "ИС", opColor: "var(--nb-bg-alt)", opName: "Иван Сидоров", machine: "CAT-101", raw: "Наработка 6 часов", intent: "hours_log", tags: [["hours_log", "mint"], ["6ч", "ink"]], conf: "94%", severity: null, ext: { Intent: "hours_log", Hours: "6ч", Conf: "94%" } },
  { time: "09:47", op: "ПК", opColor: "var(--nb-bg-alt)", opName: "Пётр Кузнецов", machine: "BLZ-042", raw: "Гидравлика не поднимает кузов", intent: "issue_report", tags: [["issue_report", "yellow"], ["hydraulics", "ink"], ["warning", "yellow"]], conf: "88%", severity: "warn", ext: { Intent: "issue_report", Component: "hydraulics", Severity: "warning", Conf: "88%" } },
  { time: "09:49", op: "ПК", opColor: "var(--nb-bg-alt)", opName: "Пётр Кузнецов", machine: "BLZ-042", raw: "Стоим, началось после загрузки", intent: "status_update", tags: [["status_update", "violet"]], conf: "91%", severity: "warn", ext: { Intent: "status_update", Context: "after loading", Conf: "91%" } },
  { time: "10:05", op: "ИС", opColor: "var(--nb-bg-alt)", opName: "Иван Сидоров", machine: "CAT-101", raw: "Вывезли 18 кубов грунта", intent: "production_log", tags: [["production_log", "violet"], ["18 кубов", "ink"]], conf: "92%", severity: null, ext: { Intent: "production_log", Qty: "18 кубов", Conf: "92%" } },
  { time: "10:15", op: "МФ", opColor: "var(--nb-bg-alt)", opName: "Михаил Фёдоров", machine: "KOM-007", raw: "Нужен фильтр гидравлический", intent: "parts_request", tags: [["parts_request", "pink"], ["hydraulic filter", "ink"]], conf: "92%", severity: null, ext: { Intent: "parts_request", Part: "hydraulic filter", Conf: "92%" } },
  { time: "10:30", op: "ИС", opColor: "var(--nb-bg-alt)", opName: "Иван Сидоров", machine: "CAT-101", raw: "ещё 50 залил", intent: "fuel_log", tags: [["fuel_log", "sky"], ["50л", "ink"], ["context-inferred", "yellow"]], conf: "87%", severity: null, ext: { Intent: "fuel_log", Volume: "50л", Context: "inferred", Conf: "87%" } },
  { time: "11:10", op: "МФ", opColor: "var(--nb-bg-alt)", opName: "Михаил Фёдоров", machine: "KOM-007", raw: "Наработка 3 часа", intent: "hours_log", tags: [["hours_log", "mint"], ["3ч", "ink"]], conf: "94%", severity: null, ext: { Intent: "hours_log", Hours: "3ч", Conf: "94%" } },
];

const FLEET = {
  "CAT-101": { type: "Excavator", typeRu: "Экскаватор", model: "Caterpillar 320D · 2019", op: "Иван Сидоров", status: "working", fuel: 200, hours: 6, prod: 18, prodUnit: "куб", issues: 0 },
  "BLZ-042": { type: "Dump truck", typeRu: "Самосвал", model: "БелАЗ 75131 · 2020", op: "Пётр Кузнецов", status: "warning", fuel: 80, hours: 3, prod: 0, prodUnit: "—", issues: 1 },
  "KOM-007": { type: "Bulldozer", typeRu: "Бульдозер", model: "Komatsu D155AX · 2018", op: "Михаил Фёдоров", status: "working", fuel: 0, hours: 3, prod: 0, prodUnit: "—", issues: 0 },
  "GRD-003": { type: "Grader", typeRu: "Грейдер", model: "ВГМТ 14ГМ · 2021", op: null, status: "idle", fuel: 0, hours: 0, prod: 0, prodUnit: "—", issues: 0 },
  "KRN-005": { type: "Crane", typeRu: "Кран", model: "Liebherr LTM 1100 · 2017", op: null, status: "idle", fuel: 0, hours: 0, prod: 0, prodUnit: "—", issues: 0 },
};

const OPEN_ISSUES = [
  { machine: "BLZ-042", title: "Гидравлика не поднимает кузов", time: "09:47", op: "Пётр Кузнецов", severity: "MEDIUM", orig: "\"Гидравлика не поднимает кузов\" → component: hydraulics", action: "Notify mechanic" },
];

const INSIGHTS = [
  { kind: "anomaly", title: "CAT-101 fuel rate 33 L/h — 18% above baseline", body: "Last 3 days trending up. Possible idling, leak, or operator habit.", color: "var(--nb-yellow)", icon: "▲" },
  { kind: "pattern", title: "Hydraulics failures cluster on БелАЗ fleet", body: "3rd hydraulics report in 14 days (BLZ-042 today, BLZ-018 +5d, BLZ-042 +12d).", color: "var(--nb-coral)", icon: "◆" },
  { kind: "opportunity", title: "GRD-003 idle for 4 days", body: "No shift opened. Reassign or schedule maintenance window.", color: "var(--nb-sky)", icon: "◉" },
];

function StatusPill({ status }) {
  const map = {
    working: { bg: "var(--nb-lime)", label: "WORKING" },
    warning: { bg: "var(--nb-yellow)", label: "WARNING" },
    idle: { bg: "#e5e1d4", label: "IDLE" },
    down: { bg: "var(--nb-coral)", label: "DOWN" },
  };
  const s = map[status] || map.idle;
  return (
    <span style={{
      fontFamily: "var(--nb-mono)", fontSize: 10, fontWeight: 800,
      padding: "3px 9px", background: s.bg,
      border: "2px solid var(--nb-ink)", borderRadius: 4,
      letterSpacing: ".06em",
    }}>{s.label}</span>
  );
}

function Avatar2({ initials, color, size = 28 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: color, border: "2px solid var(--nb-ink)",
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "var(--nb-mono)", fontWeight: 700, fontSize: size * 0.34,
      flexShrink: 0, color: "var(--nb-ink)",
    }}>{initials}</div>
  );
}

function MetricBlock({ label, value, unit, sub, subTone, accent }) {
  const subColor = { good: "#0a7d2c", bad: "#a8201a", muted: "var(--nb-muted)" }[subTone || "muted"];
  return (
    <div style={{
      padding: "16px 18px",
      background: accent || "var(--nb-paper)",
      borderRight: "2px solid var(--nb-ink)",
      flex: 1, minWidth: 0,
    }}>
      <div className="nb-label">{label}</div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginTop: 6 }}>
        <span style={{ fontSize: 30, fontWeight: 800, lineHeight: 1, letterSpacing: "-.02em" }}>{value}</span>
        {unit && <span style={{ fontFamily: "var(--nb-mono)", fontSize: 13, fontWeight: 600, color: "var(--nb-ink-soft)" }}>{unit}</span>}
      </div>
      {sub && <div style={{ fontFamily: "var(--nb-mono)", fontSize: 10.5, fontWeight: 600, color: subColor, marginTop: 6, textTransform: "uppercase", letterSpacing: ".05em" }}>{sub}</div>}
    </div>
  );
}

function SummaryTab() {
  const total = Object.keys(FLEET).length;
  const working = Object.values(FLEET).filter(m => m.status === "working").length;
  const warn = Object.values(FLEET).filter(m => m.status === "warning").length;
  const idle = Object.values(FLEET).filter(m => m.status === "idle").length;
  const fuelTotal = Object.values(FLEET).reduce((a, m) => a + m.fuel, 0);
  const hoursTotal = Object.values(FLEET).reduce((a, m) => a + m.hours, 0);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>
      <div style={{ display: "flex", borderBottom: "var(--nb-border-thick)", background: "var(--nb-paper)" }}>
        <MetricBlock label="Fleet uptime" value={`${working}/${total}`} sub={`${warn} warning · ${idle} idle`} subTone="muted" />
        <MetricBlock label="Hours logged today" value={hoursTotal} unit="h" sub="across 3 operators" subTone="muted" />
        <MetricBlock label="Fuel today" value={fuelTotal} unit="L" sub="↑ 8% vs 7-day avg" subTone="bad" />
        <MetricBlock label="Open issues" value={OPEN_ISSUES.length} sub="MEDIUM · BLZ-042" subTone="bad" accent="var(--nb-yellow)" />
        <div style={{ padding: "16px 18px", background: "var(--nb-paper)", flex: 1 }}>
          <div className="nb-label">Production today</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginTop: 6 }}>
            <span style={{ fontSize: 30, fontWeight: 800, lineHeight: 1 }}>18</span>
            <span style={{ fontFamily: "var(--nb-mono)", fontSize: 13, color: "var(--nb-ink-soft)" }}>m³</span>
          </div>
          <div style={{ fontFamily: "var(--nb-mono)", fontSize: 10.5, color: "var(--nb-muted)", marginTop: 6, textTransform: "uppercase", letterSpacing: ".05em" }}>CAT-101 only</div>
        </div>
      </div>

      <div className="nb-scroll" style={{ flex: 1, overflowY: "auto", padding: 18, display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 18, alignContent: "start" }}>
        <div style={{ gridColumn: "1 / -1" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
            <div style={{ background: "var(--nb-ink)", color: "#fff", fontFamily: "var(--nb-mono)", fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 4, letterSpacing: ".08em" }}>VFM INTELLIGENCE</div>
            <span style={{ fontFamily: "var(--nb-mono)", fontSize: 11, color: "var(--nb-muted)" }}>{INSIGHTS.length} insights from 3 days of natural-language logs</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
            {INSIGHTS.map((ins, i) => (
              <div key={i} className="nb-card" style={{ padding: 14, background: ins.color }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                  <div style={{ width: 26, height: 26, background: "var(--nb-ink)", color: "#fff", border: "2px solid var(--nb-ink)", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 800 }}>{ins.icon}</div>
                  <span className="nb-tag ink">{ins.kind}</span>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, lineHeight: 1.25, marginBottom: 6 }}>{ins.title}</div>
                <div style={{ fontSize: 12, lineHeight: 1.45, color: "var(--nb-ink-soft)" }}>{ins.body}</div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="nb-label" style={{ marginBottom: 8 }}>Open issues</div>
          {OPEN_ISSUES.map((iss, i) => (
            <div key={i} className="nb-card" style={{ padding: 14, marginBottom: 10, background: "var(--nb-yellow)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                <span className="nb-tag ink">{iss.severity}</span>
                <span style={{ fontFamily: "var(--nb-mono)", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>{iss.machine}</span>
                <span style={{ fontFamily: "var(--nb-mono)", fontSize: 10.5, color: "var(--nb-ink-soft)", marginLeft: "auto", whiteSpace: "nowrap" }}>{iss.time}</span>
              </div>
              <div style={{ fontSize: 14, fontWeight: 700, lineHeight: 1.3 }}>{iss.title}</div>
              <div style={{ fontFamily: "var(--nb-mono)", fontSize: 11, color: "var(--nb-ink-soft)", marginTop: 4 }}>reported by {iss.op}</div>
              <div style={{ fontSize: 12, fontStyle: "italic", color: "var(--nb-ink-soft)", marginTop: 6, paddingTop: 6, borderTop: "1.5px dashed rgba(0,0,0,0.3)" }}>{iss.orig}</div>
              <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
                <button className="nb-btn ink">{iss.action}</button>
                <button className="nb-btn">Mark resolved</button>
              </div>
            </div>
          ))}
        </div>

        <div>
          <div className="nb-label" style={{ marginBottom: 8 }}>Today's activity</div>
          <div className="nb-card" style={{ padding: 0, overflow: "hidden" }}>
            {FLEET_LOGS.slice(0, 7).map((l, i) => (
              <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "9px 12px", borderBottom: i < 6 ? "1.5px solid var(--nb-ink)" : "none", background: l.severity === "warn" ? "var(--nb-yellow)" : "var(--nb-paper)" }}>
                <span style={{ fontFamily: "var(--nb-mono)", fontSize: 10.5, fontWeight: 700, minWidth: 36 }}>{l.time}</span>
                <Avatar2 initials={l.op} color={l.opColor} size={22} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12.5, lineHeight: 1.3 }}>{l.raw}</div>
                  <div style={{ fontFamily: "var(--nb-mono)", fontSize: 10, color: "var(--nb-muted)", marginTop: 2 }}>{l.opName} · {l.machine}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MachineLogsTab() {
  const [expanded, setExpanded] = React.useState(new Set([6]));
  const [filter, setFilter] = React.useState("all");
  const filters = ["all", "fuel_log", "hours_log", "issue_report", "production_log", "parts_request"];
  const visible = filter === "all" ? FLEET_LOGS : FLEET_LOGS.filter(l => l.intent === filter);
  const toggle = (i) => {
    const next = new Set(expanded);
    if (next.has(i)) next.delete(i); else next.add(i);
    setExpanded(next);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", padding: "12px 18px", borderBottom: "2px solid var(--nb-ink)", background: "var(--nb-bg-alt)" }}>
        <span className="nb-label">Filter intent</span>
        {filters.map(f => (
          <button key={f} className="nb-btn" style={{ background: filter === f ? "var(--nb-yellow)" : "var(--nb-paper)", color: "var(--nb-ink)", boxShadow: filter === f ? "var(--nb-shadow-sm)" : "none" }} onClick={() => setFilter(f)}>{f}</button>
        ))}
        <span style={{ marginLeft: "auto", fontFamily: "var(--nb-mono)", fontSize: 11, color: "var(--nb-muted)" }}>{visible.length} of {FLEET_LOGS.length} messages</span>
      </div>

      <div className="nb-scroll" style={{ flex: 1, overflowY: "auto", padding: 18 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {visible.map((l, i) => {
            const isExp = expanded.has(i);
            return (
              <div key={i} onClick={() => toggle(i)} className="nb-card" style={{ padding: 0, background: l.severity === "warn" ? "var(--nb-yellow)" : "var(--nb-paper)", cursor: "pointer" }}>
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "12px 14px" }}>
                  <span style={{ fontFamily: "var(--nb-mono)", fontSize: 11, fontWeight: 700, minWidth: 42, paddingTop: 2 }}>{l.time}</span>
                  <Avatar2 initials={l.op} color={l.opColor} size={30} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
                      <span style={{ fontWeight: 700, fontSize: 12.5, whiteSpace: "nowrap" }}>{l.opName}</span>
                      <span style={{ fontFamily: "var(--nb-mono)", fontSize: 11, color: "var(--nb-muted)" }}>·</span>
                      <span style={{ fontFamily: "var(--nb-mono)", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>{l.machine}</span>
                    </div>
                    <div style={{ fontSize: 14, lineHeight: 1.4, marginBottom: 6 }}>{l.raw}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                      {l.tags.map((t, j) => <span key={j} className={`nb-tag ${t[1]}`}>{t[0]}</span>)}
                    </div>
                  </div>
                  <span style={{ fontFamily: "var(--nb-mono)", fontSize: 10, fontWeight: 700, background: "var(--nb-ink)", color: "#fff", padding: "3px 8px", borderRadius: 4, flexShrink: 0 }}>{l.conf}</span>
                </div>
                {isExp && (
                  <div style={{ borderTop: "2px solid var(--nb-ink)", background: "var(--nb-bg-alt)", padding: "10px 14px" }}>
                    <div className="nb-label" style={{ marginBottom: 6 }}>Extracted data points</div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 8 }}>
                      {Object.entries(l.ext).map(([k, v]) => (
                        <div key={k} style={{ background: "var(--nb-paper)", border: "2px solid var(--nb-ink)", borderRadius: 4, padding: "6px 10px" }}>
                          <div style={{ fontFamily: "var(--nb-mono)", fontSize: 9.5, color: "var(--nb-muted)", textTransform: "uppercase", letterSpacing: ".08em" }}>{k}</div>
                          <div style={{ fontSize: 13, fontWeight: 700, marginTop: 2 }}>{v}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function FleetTab() {
  const [selected, setSelected] = React.useState("CAT-101");
  const m = FLEET[selected];
  const fuelRate = m.hours > 0 ? Math.round(m.fuel / m.hours) : 0;
  const machineLogs = FLEET_LOGS.filter(l => l.machine === selected);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", height: "100%", overflow: "hidden" }}>
      <div style={{ background: "var(--nb-bg-alt)", borderRight: "2px solid var(--nb-ink)", display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ padding: "12px 14px", borderBottom: "2px solid var(--nb-ink)", background: "var(--nb-paper)" }}>
          <div className="nb-label">Fleet · 5 machines</div>
        </div>
        <div className="nb-scroll" style={{ overflowY: "auto", flex: 1 }}>
          {Object.entries(FLEET).map(([reg, mm]) => (
            <div key={reg} onClick={() => setSelected(reg)} style={{ padding: "12px 14px", cursor: "pointer", background: selected === reg ? "var(--nb-yellow)" : "transparent", borderBottom: "2px solid var(--nb-ink)", display: "flex", flexDirection: "column", gap: 4 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontFamily: "var(--nb-mono)", fontSize: 13, fontWeight: 800, letterSpacing: ".02em", whiteSpace: "nowrap" }}>{reg}</span>
                <span style={{ marginLeft: "auto", flexShrink: 0 }}><StatusPill status={mm.status} /></span>
              </div>
              <div style={{ fontSize: 12, color: "var(--nb-ink-soft)" }}>{mm.type} · {mm.typeRu}</div>
              <div style={{ fontFamily: "var(--nb-mono)", fontSize: 10.5, color: "var(--nb-muted)" }}>{mm.op || "no operator"}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="nb-scroll" style={{ overflowY: "auto" }}>
        <div style={{ padding: "20px 22px", borderBottom: "var(--nb-border-thick)", background: "var(--nb-bg-alt)", borderLeft: "8px solid var(--nb-yellow)", display: "flex", alignItems: "flex-start", gap: 16 }}>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ fontFamily: "var(--nb-mono)", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".1em", marginBottom: 4 }}>{m.type}</div>
            <div style={{ fontSize: 36, fontWeight: 800, lineHeight: 1, letterSpacing: "-.02em", whiteSpace: "nowrap" }}>{selected}</div>
            <div style={{ fontFamily: "var(--nb-mono)", fontSize: 12, marginTop: 6, color: "var(--nb-ink-soft)", whiteSpace: "nowrap" }}>{m.model}</div>
            <div style={{ fontSize: 13, fontWeight: 600, marginTop: 8, whiteSpace: "nowrap" }}>{m.op ? `OPERATOR: ${m.op}` : "NO ACTIVE OPERATOR"}</div>
          </div>
          <div style={{ marginLeft: "auto", flexShrink: 0 }}><StatusPill status={m.status} /></div>
        </div>

        <div style={{ display: "flex", borderBottom: "var(--nb-border-thick)", background: "var(--nb-paper)" }}>
          <MetricBlock label="Fuel today" value={m.fuel} unit="L" sub={`${fuelRate} L/h · ${fuelRate > 30 ? "anomaly" : "normal"}`} subTone={fuelRate > 30 ? "bad" : "good"} />
          <MetricBlock label="Hours today" value={m.hours} unit="h" sub={m.hours > 0 ? "on track" : "no activity"} subTone={m.hours > 0 ? "good" : "muted"} />
          <MetricBlock label="Production" value={m.prod} unit={m.prodUnit !== "—" ? m.prodUnit : ""} sub={m.prod > 0 ? "logged" : "not logged"} subTone="muted" />
          <div style={{ padding: "16px 18px", background: m.issues > 0 ? "var(--nb-coral)" : "var(--nb-paper)", flex: 1 }}>
            <div className="nb-label">Open issues</div>
            <div style={{ fontSize: 30, fontWeight: 800, marginTop: 6, lineHeight: 1 }}>{m.issues}</div>
            <div style={{ fontFamily: "var(--nb-mono)", fontSize: 10.5, fontWeight: 700, color: m.issues > 0 ? "#791f1f" : "var(--nb-muted)", marginTop: 6, textTransform: "uppercase", letterSpacing: ".05em" }}>{m.issues > 0 ? "action needed" : "clear"}</div>
          </div>
        </div>

        <div style={{ padding: 18 }}>
          {OPEN_ISSUES.filter(i => i.machine === selected).length > 0 && (
            <>
              <div className="nb-label" style={{ marginBottom: 8 }}>Open issues</div>
              {OPEN_ISSUES.filter(i => i.machine === selected).map((iss, i) => (
                <div key={i} className="nb-card" style={{ padding: 14, marginBottom: 14, background: "var(--nb-yellow)" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                    <span className="nb-tag ink">{iss.severity}</span>
                    <span style={{ fontFamily: "var(--nb-mono)", fontSize: 11, fontWeight: 700 }}>{iss.time}</span>
                    <span style={{ marginLeft: "auto", fontFamily: "var(--nb-mono)", fontSize: 11 }}>{iss.op}</span>
                  </div>
                  <div style={{ fontSize: 15, fontWeight: 700, lineHeight: 1.3 }}>{iss.title}</div>
                  <div style={{ fontSize: 12, fontStyle: "italic", color: "var(--nb-ink-soft)", marginTop: 6 }}>{iss.orig}</div>
                </div>
              ))}
            </>
          )}

          <div className="nb-label" style={{ marginBottom: 8 }}>Today's log · {selected}</div>
          {machineLogs.length === 0 ? (
            <div className="nb-card" style={{ padding: 20, textAlign: "center", fontFamily: "var(--nb-mono)", fontSize: 12, color: "var(--nb-muted)" }}>No activity today</div>
          ) : (
            <div className="nb-card" style={{ padding: 0, overflow: "hidden" }}>
              {machineLogs.map((l, i) => (
                <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "10px 14px", borderBottom: i < machineLogs.length - 1 ? "1.5px solid var(--nb-ink)" : "none", background: l.severity === "warn" ? "var(--nb-yellow)" : "var(--nb-paper)" }}>
                  <span style={{ fontFamily: "var(--nb-mono)", fontSize: 11, fontWeight: 700, minWidth: 42, paddingTop: 2 }}>{l.time}</span>
                  <Avatar2 initials={l.op} color={l.opColor} size={24} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, lineHeight: 1.4 }}>{l.raw}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 4 }}>
                      {l.tags.map((t, j) => <span key={j} className={`nb-tag ${t[1]}`}>{t[0]}</span>)}
                    </div>
                  </div>
                  <span style={{ fontFamily: "var(--nb-mono)", fontSize: 10, fontWeight: 700, background: "var(--nb-ink)", color: "#fff", padding: "2px 7px", borderRadius: 4, marginTop: 2 }}>{l.conf}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function FleetIntelligence() {
  const [tab, setTab] = React.useState("summary");
  const tabs = [
    { id: "summary", label: "Summary", icon: "▣", color: "var(--nb-yellow)" },
    { id: "logs", label: "Machine Logs", icon: "≡", color: "var(--nb-yellow)" },
    { id: "fleet", label: "Fleet", icon: "◫", color: "var(--nb-yellow)" },
  ];

  return (
    <div style={{
      width: 1200, height: 820,
      background: "var(--nb-bg)",
      border: "var(--nb-border-thick)",
      borderRadius: 10,
      display: "grid",
      gridTemplateRows: "56px 60px 1fr",
      overflow: "hidden",
      boxShadow: "var(--nb-shadow-lg)",
      fontFamily: "var(--nb-font)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 22px", background: "var(--nb-ink)", color: "#fff", borderBottom: "var(--nb-border-thick)" }}>
        <div style={{ width: 30, height: 30, background: "var(--nb-lime)", border: "2px solid #fff", borderRadius: 4, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, color: "var(--nb-ink)", fontSize: 13 }}>L</div>
        <div style={{ fontWeight: 700, fontSize: 16, letterSpacing: "-.01em" }}>LOGBUK</div>
        <span className="nb-tag" style={{ background: "var(--nb-yellow)", borderColor: "#fff" }}>fleet intelligence · owner</span>
        <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
          <span className="nb-tag" style={{ background: "var(--nb-coral)", borderColor: "#fff" }}>1 open issue</span>
          <span className="nb-tag" style={{ background: "var(--nb-lime)", borderColor: "#fff" }}>3 shifts active</span>
          <Avatar2 initials="ОВ" color="var(--nb-paper)" size={30} />
        </div>
      </div>

      <div style={{ display: "flex", padding: "10px 22px 0", background: "var(--nb-bg)", borderBottom: "var(--nb-border-thick)", alignItems: "flex-end" }}>
        {tabs.map(t => {
          const active = t.id === tab;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              fontFamily: "var(--nb-font)", fontWeight: 700, fontSize: 14,
              padding: "10px 20px",
              background: active ? t.color : "var(--nb-paper)",
              color: "var(--nb-ink)",
              border: "2px solid var(--nb-ink)",
              borderBottom: active ? "2px solid " + t.color : "2px solid var(--nb-ink)",
              borderRadius: "8px 8px 0 0",
              cursor: "pointer",
              marginRight: 4,
              marginBottom: -2,
              position: "relative",
              zIndex: active ? 2 : 1,
              boxShadow: active ? "3px -2px 0 0 var(--nb-ink)" : "none",
              display: "flex", alignItems: "center", gap: 8,
              transform: active ? "translateY(0)" : "translateY(2px)",
            }}>
              <span style={{ fontSize: 16 }}>{t.icon}</span>
              {t.label}
              {t.id === "logs" && (<span style={{ fontFamily: "var(--nb-mono)", fontSize: 10, fontWeight: 700, padding: "1px 6px", background: active ? "var(--nb-ink)" : "var(--nb-bg-alt)", color: active ? "#fff" : "var(--nb-ink)", borderRadius: 999, border: "1.5px solid var(--nb-ink)" }}>{FLEET_LOGS.length}</span>)}
              {t.id === "fleet" && (<span style={{ fontFamily: "var(--nb-mono)", fontSize: 10, fontWeight: 700, padding: "1px 6px", background: active ? "var(--nb-ink)" : "var(--nb-bg-alt)", color: active ? "#fff" : "var(--nb-ink)", borderRadius: 999, border: "1.5px solid var(--nb-ink)" }}>5</span>)}
            </button>
          );
        })}
        <div style={{ marginLeft: "auto", paddingBottom: 12, display: "flex", gap: 8 }}>
          <button className="nb-btn">Today ▾</button>
          <button className="nb-btn lime">Export</button>
        </div>
      </div>

      <div style={{ overflow: "hidden", background: "var(--nb-bg)" }}>
        {tab === "summary" && <SummaryTab />}
        {tab === "logs" && <MachineLogsTab />}
        {tab === "fleet" && <FleetTab />}
      </div>
    </div>
  );
}

window.FleetIntelligence = FleetIntelligence;

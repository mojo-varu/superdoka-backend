/* Operator Sandbox — neobrutalism rebuild */

const OPS = {
  ivan: {
    name: "Иван Сидоров", role: "Excavator operator", av: "ИС", color: "var(--nb-paper)",
    machines: [
      { reg: "CAT-101", active: true, status: "working" },
      { reg: "BLZ-042", active: false, status: "idle" },
    ],
    activeMachine: "CAT-101", shiftOn: true,
    history: [
      { from: "op", text: "Начинаю смену на CAT-101", ts: "07:02" },
      { from: "sys", tone: "ok", text: "Смена открыта. Машина CAT-101 активна. Удачной смены!", ts: "07:02", ext: { intent: "shift_start", conf: "97%" } },
      { from: "op", text: "Залил 150 литров", ts: "08:15" },
      { from: "sys", tone: "ok", text: "Записано: 150л топлива", ts: "08:15", ext: { intent: "fuel_log", fields: "vol: 150л", conf: "96%" } },
      { from: "op", text: "Наработка 6 часов", ts: "09:30" },
      { from: "sys", tone: "ok", text: "Записано: 6ч наработки", ts: "09:30", ext: { intent: "hours_log", fields: "hours: 6ч", conf: "94%" } },
    ],
  },
  petr: {
    name: "Пётр Кузнецов", role: "Dump truck operator", av: "ПК", color: "var(--nb-paper)",
    machines: [{ reg: "BLZ-042", active: true, status: "warning" }],
    activeMachine: "BLZ-042", shiftOn: true,
    history: [
      { from: "op", text: "Начинаю смену на BLZ-042", ts: "07:10" },
      { from: "sys", tone: "ok", text: "Смена открыта. Машина BLZ-042 активна.", ts: "07:10", ext: { intent: "shift_start", conf: "97%" } },
      { from: "op", text: "Залил 80л солярки", ts: "08:00" },
      { from: "sys", tone: "ok", text: "Записано: 80л топлива", ts: "08:00", ext: { intent: "fuel_log", fields: "vol: 80л", conf: "93%" } },
      { from: "op", text: "Гидравлика не поднимает кузов", ts: "09:47" },
      { from: "sys", tone: "warn", text: "Зафиксировано: гидравлика, MEDIUM. Механик уведомлён.", ts: "09:47", ext: { intent: "issue_report", fields: "hydraulics · warning", conf: "88%" } },
      { from: "sys", tone: "ok", text: "VFM: Опишите подробнее — когда впервые появилось? Работаете или стоите?", ts: "09:48" },
      { from: "op", text: "Стоим, началось после загрузки", ts: "09:49" },
      { from: "sys", tone: "warn", text: "Записано. Рекомендую не продолжать до осмотра механика.", ts: "09:49", ext: { intent: "status_update", fields: "context added", conf: "91%" } },
    ],
  },
  misha: {
    name: "Михаил Фёдоров", role: "Bulldozer operator", av: "МФ", color: "var(--nb-paper)",
    machines: [{ reg: "KOM-007", active: true, status: "working" }],
    activeMachine: "KOM-007", shiftOn: true,
    history: [
      { from: "op", text: "начинаю KOM-007", ts: "07:30" },
      { from: "sys", tone: "ok", text: "Смена открыта. Машина KOM-007 активна.", ts: "07:30", ext: { intent: "shift_start", conf: "95%" } },
      { from: "op", text: "Нужен фильтр гидравлический", ts: "10:15" },
      { from: "sys", tone: "ok", text: "Запрос запчасти зафиксирован: гидравлический фильтр, KOM-007.", ts: "10:15", ext: { intent: "parts_request", fields: "hydraulic filter", conf: "92%" } },
    ],
  },
  sergey: {
    name: "Сергей Власов", role: "Multi-machine operator", av: "СВ", color: "var(--nb-paper)",
    machines: [{ reg: "GRD-003", active: false, status: "idle" }, { reg: "KRN-005", active: false, status: "idle" }],
    activeMachine: null, shiftOn: false,
    history: [],
  },
};

function classifyReply(text) {
  const t = text.toLowerCase();
  if (/начин|смену|смена/.test(t)) return { tone: "ok", text: "Смена открыта. Удачной смены!", ext: { intent: "shift_start", conf: "97%" } };
  if (/конч|закон|завершил/.test(t)) return { tone: "ok", text: "Смена закрыта. Итоги рассчитаны.", ext: { intent: "shift_end", conf: "96%" } };
  if (/залил|топлив|солярк|заправ/.test(t)) {
    const n = t.match(/\d+/); const v = n ? n[0] : "?";
    return { tone: "ok", text: `Записано: ${v}л топлива`, ext: { intent: "fuel_log", fields: `vol: ${v}л`, conf: "93%" } };
  }
  if (/наработ|часов|\dч/.test(t)) {
    const n = t.match(/\d+/); const h = n ? n[0] : "?";
    return { tone: "ok", text: `Записано: ${h}ч наработки`, ext: { intent: "hours_log", fields: `hours: ${h}ч`, conf: "94%" } };
  }
  if (/пожар|горит|fire/.test(t)) return { tone: "bad", text: "КРИТИЧНО зафиксировано. Машина остановлена. Владелец уведомлён.", ext: { intent: "issue_report", fields: "severity: critical", conf: "97%" } };
  if (/стучит|течь|масло|гидравл|неисправ|сломал|проблем/.test(t)) return { tone: "warn", text: "Зафиксировано. Приоритет MEDIUM. Уточните детали.", ext: { intent: "issue_report", fields: "severity: warning", conf: "87%" } };
  if (/куб|рейс|тонн|вывезли/.test(t)) {
    const n = t.match(/\d+/);
    return { tone: "ok", text: "Выработка записана", ext: { intent: "production_log", fields: n ? `qty: ${n[0]}` : "qty: ?", conf: "90%" } };
  }
  if (/запчаст|фильтр|нужн|замен/.test(t)) return { tone: "ok", text: "Запрос на запчасть зафиксирован. Передан владельцу.", ext: { intent: "parts_request", fields: "logged", conf: "89%" } };
  return { tone: "ok", text: "Принято", ext: { intent: "status_update", conf: "82%" } };
}

function StatusDot({ status }) {
  const colors = { working: "var(--nb-good)", warning: "var(--nb-warn)", idle: "#cdc9bd", down: "var(--nb-bad)" };
  return <span style={{ width: 10, height: 10, borderRadius: "50%", background: colors[status], border: "1.5px solid var(--nb-ink)", flexShrink: 0 }} />;
}

function Avatar({ initials, color, size = 36 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: "50%",
      background: color, border: "2px solid var(--nb-ink)",
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "var(--nb-mono)", fontWeight: 700, fontSize: size * 0.32,
      flexShrink: 0, boxShadow: "2px 2px 0 0 var(--nb-ink)",
    }}>{initials}</div>
  );
}

function OperatorChip({ op, active, onClick }) {
  return (
    <div onClick={onClick} style={{
      cursor: "pointer",
      padding: "10px 12px",
      display: "flex", alignItems: "center", gap: 10,
      background: active ? "var(--nb-yellow)" : "var(--nb-paper)",
      borderBottom: "2px solid var(--nb-ink)",
      transition: "background .12s",
    }}>
      <Avatar initials={op.av} color={active ? "var(--nb-paper)" : "var(--nb-bg-alt)"} size={34} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 13, lineHeight: 1.2 }}>{op.name}</div>
        <div style={{ fontFamily: "var(--nb-mono)", fontSize: 10, color: "var(--nb-ink-soft)", marginTop: 2 }}>
          {op.machines.map(m => m.reg).join(" · ")}
        </div>
      </div>
      <StatusDot status={op.shiftOn ? "working" : "idle"} />
    </div>
  );
}

function Bubble({ msg, opColor }) {
  if (msg.from === "op") {
    return (
      <div style={{ alignSelf: "flex-end", maxWidth: "78%" }}>
        <div style={{
          background: opColor,
          border: "2px solid var(--nb-ink)",
          borderRadius: "12px 12px 4px 12px",
          padding: "8px 12px",
          boxShadow: "3px 3px 0 0 var(--nb-ink)",
          fontSize: 13.5, fontWeight: 500, lineHeight: 1.45,
        }}>{msg.text}</div>
        <div style={{ fontFamily: "var(--nb-mono)", fontSize: 9.5, color: "var(--nb-muted)", marginTop: 3, textAlign: "right" }}>{msg.ts}</div>
      </div>
    );
  }
  const toneBg = { ok: "var(--nb-paper)", warn: "var(--nb-yellow)", bad: "var(--nb-coral)" }[msg.tone || "ok"];
  return (
    <div style={{ alignSelf: "flex-start", maxWidth: "82%" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
        <div style={{
          width: 22, height: 22, borderRadius: "50%",
          background: "var(--nb-ink)", color: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontFamily: "var(--nb-mono)", fontSize: 9, fontWeight: 700,
          border: "2px solid var(--nb-ink)",
        }}>VFM</div>
        <span style={{ fontFamily: "var(--nb-mono)", fontSize: 9.5, color: "var(--nb-muted)", textTransform: "uppercase", letterSpacing: ".08em" }}>
          assistant · {msg.ts}
        </span>
      </div>
      <div style={{
        background: toneBg,
        border: "2px solid var(--nb-ink)",
        borderRadius: "4px 12px 12px 12px",
        padding: "8px 12px",
        boxShadow: "3px 3px 0 0 var(--nb-ink)",
        fontSize: 13, lineHeight: 1.45,
      }}>
        {msg.text}
        {msg.ext && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 6, paddingTop: 6, borderTop: "1.5px dashed rgba(0,0,0,0.25)" }}>
            <span className="nb-tag ink">{msg.ext.intent}</span>
            {msg.ext.fields && <span className="nb-tag">{msg.ext.fields}</span>}
            <span className="nb-tag" style={{ fontWeight: 600 }}>conf {msg.ext.conf}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function MachinePill({ m, onClick }) {
  let bg = "var(--nb-paper)";
  if (m.active && m.status === "warning") bg = "var(--nb-coral)";
  else if (m.active) bg = "var(--nb-yellow)";
  return (
    <span onClick={onClick} style={{
      fontFamily: "var(--nb-mono)", fontSize: 11, fontWeight: 700,
      padding: "4px 10px",
      background: bg,
      border: "2px solid var(--nb-ink)",
      borderRadius: 4,
      boxShadow: m.active ? "2px 2px 0 0 var(--nb-ink)" : "none",
      cursor: "pointer",
      transition: "all .1s",
      letterSpacing: ".02em",
    }}>{m.reg}</span>
  );
}

function OperatorSandbox() {
  const [opData, setOpData] = React.useState(() => JSON.parse(JSON.stringify(OPS)));
  const [currentId, setCurrentId] = React.useState("petr");
  const [draft, setDraft] = React.useState("");
  const msgsRef = React.useRef(null);

  const op = opData[currentId];

  React.useEffect(() => {
    if (msgsRef.current) msgsRef.current.scrollTop = msgsRef.current.scrollHeight;
  }, [op.history.length, currentId]);

  const send = (textArg) => {
    const text = (textArg ?? draft).trim();
    if (!text) return;
    const now = new Date().toLocaleTimeString("ru", { hour: "2-digit", minute: "2-digit" });
    setDraft("");
    setOpData(prev => {
      const next = { ...prev };
      const o = { ...next[currentId] };
      o.history = [...o.history, { from: "op", text, ts: now }];
      next[currentId] = o;
      return next;
    });
    setTimeout(() => {
      const reply = classifyReply(text);
      const replyTs = new Date().toLocaleTimeString("ru", { hour: "2-digit", minute: "2-digit" });
      setOpData(prev => {
        const next = { ...prev };
        const o = { ...next[currentId] };
        o.history = [...o.history, { from: "sys", tone: reply.tone, text: reply.text, ts: replyTs, ext: reply.ext }];
        if (/начин|смену/.test(text.toLowerCase())) o.shiftOn = true;
        if (/конч|закон|заверш/.test(text.toLowerCase())) o.shiftOn = false;
        next[currentId] = o;
        return next;
      });
    }, 550);
  };

  const switchMachine = (reg) => {
    setOpData(prev => {
      const next = { ...prev };
      const o = { ...next[currentId] };
      o.activeMachine = reg;
      o.machines = o.machines.map(m => ({ ...m, active: m.reg === reg }));
      const now = new Date().toLocaleTimeString("ru", { hour: "2-digit", minute: "2-digit" });
      o.history = [...o.history, { from: "sys", tone: "ok", text: `Переключено на ${reg}`, ts: now, ext: { intent: "machine_switch", fields: reg, conf: "99%" } }];
      next[currentId] = o;
      return next;
    });
  };

  const toggleShift = () => {
    if (!op.shiftOn) send(`Начинаю смену на ${op.machines[0].reg}`);
    else send("Смена закончена");
  };

  const quick = [
    { label: "+ Fuel", text: "Залил 50 литров", color: "var(--nb-paper)" },
    { label: "+ Hours", text: "Наработка 4 часа", color: "var(--nb-paper)" },
    { label: "+ Issue", text: "Гидравлика стучит", color: "var(--nb-coral)", textLight: true },
    { label: "+ Production", text: "Вывезли 15 кубов", color: "var(--nb-paper)" },
    { label: "+ Parts", text: "Нужен фильтр", color: "var(--nb-paper)" },
  ];

  return (
    <div style={{
      width: 1100, height: 760,
      background: "var(--nb-bg)",
      border: "var(--nb-border-thick)",
      borderRadius: 10,
      display: "grid",
      gridTemplateRows: "56px 1fr",
      overflow: "hidden",
      boxShadow: "var(--nb-shadow-lg)",
      fontFamily: "var(--nb-font)",
    }}>
      {/* Top bar */}
      <div style={{
        display: "flex", alignItems: "center", gap: 12,
        padding: "0 18px",
        background: "var(--nb-ink)", color: "#fff",
        borderBottom: "var(--nb-border-thick)",
      }}>
        <div style={{
          width: 30, height: 30, background: "var(--nb-lime)",
          border: "2px solid #fff", borderRadius: 4,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontWeight: 800, color: "var(--nb-ink)", fontSize: 13,
        }}>L</div>
        <div style={{ fontWeight: 700, fontSize: 16, letterSpacing: "-.01em" }}>LOGBUK</div>
        <span className="nb-tag" style={{ background: "var(--nb-yellow)", borderColor: "#fff" }}>operator console · sandbox</span>
        <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
          <span className="nb-tag" style={{ background: "var(--nb-lime)", borderColor: "#fff" }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--nb-ink)" }} />
            3 of 4 active
          </span>
        </div>
      </div>

      {/* Body */}
      <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", height: "100%", minHeight: 0 }}>
        {/* Left rail — operators */}
        <div style={{
          background: "var(--nb-bg-alt)",
          borderRight: "var(--nb-border-thick)",
          display: "flex", flexDirection: "column", overflow: "hidden",
        }}>
          <div style={{
            padding: "12px 14px 10px",
            borderBottom: "2px solid var(--nb-ink)",
            background: "var(--nb-yellow)",
          }}>
            <div className="nb-label">Operators</div>
            <div style={{ fontWeight: 700, fontSize: 18, marginTop: 2 }}>4 on roster</div>
          </div>
          <div className="nb-scroll" style={{ overflowY: "auto", flex: 1 }}>
            {Object.entries(opData).map(([id, o]) => (
              <OperatorChip key={id} op={o} active={id === currentId} onClick={() => setCurrentId(id)} />
            ))}
          </div>
          <div style={{
            padding: "10px 12px",
            borderTop: "2px solid var(--nb-ink)",
            background: "var(--nb-paper)",
            fontFamily: "var(--nb-mono)", fontSize: 10, color: "var(--nb-muted)",
            lineHeight: 1.5,
          }}>
            <div style={{ fontWeight: 700, color: "var(--nb-ink)", marginBottom: 2 }}>SANDBOX MODE</div>
            Type as the selected operator. VFM extracts intent + fields.
          </div>
        </div>

        {/* Right — chat */}
        <div style={{ display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>
          {/* Op header */}
          <div style={{
            padding: "14px 18px",
            borderBottom: "var(--nb-border-thick)",
            background: "var(--nb-paper)",
            display: "flex", flexDirection: "column", gap: 10,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <Avatar initials={op.av} color={op.color} size={42} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 18, fontWeight: 700, lineHeight: 1.1 }}>{op.name}</div>
                <div style={{ fontFamily: "var(--nb-mono)", fontSize: 11, color: "var(--nb-muted)", marginTop: 2, textTransform: "uppercase", letterSpacing: ".06em" }}>
                  {op.role} · {op.shiftOn ? "on shift" : "off shift"}
                </div>
              </div>
              <button className={`nb-btn ${op.shiftOn ? "coral" : "yellow"}`} onClick={toggleShift}>
                {op.shiftOn ? "End shift" : "Start shift"}
              </button>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              <span className="nb-label">Machines</span>
              {op.machines.map(m => <MachinePill key={m.reg} m={m} onClick={() => switchMachine(m.reg)} />)}
            </div>
          </div>

          {/* Quick action bar */}
          <div style={{
            padding: "10px 18px",
            borderBottom: "2px solid var(--nb-ink)",
            background: "var(--nb-bg-alt)",
            display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center",
          }}>
            <span className="nb-label" style={{ marginRight: 4 }}>Quick log</span>
            {quick.map(q => (
              <button key={q.label} className="nb-btn" style={{ background: q.color, color: q.textLight ? "#fafaf7" : "var(--nb-ink)" }} onClick={() => send(q.text)}>
                {q.label}
              </button>
            ))}
          </div>

          {/* Messages */}
          <div ref={msgsRef} className="nb-scroll" style={{
            flex: 1, overflowY: "auto",
            padding: "18px 18px 8px",
            display: "flex", flexDirection: "column", gap: 14,
            background: `repeating-linear-gradient(0deg, var(--nb-bg) 0 28px, var(--nb-bg) 28px 29px, rgba(10,10,10,0.04) 29px 30px)`,
          }}>
            {op.history.length === 0 ? (
              <div style={{
                margin: "auto", textAlign: "center",
                background: "var(--nb-paper)", border: "var(--nb-border)",
                borderRadius: 8, padding: "20px 28px",
                boxShadow: "var(--nb-shadow)",
              }}>
                <div style={{ fontSize: 28, fontWeight: 800 }}>No messages</div>
                <div style={{ fontFamily: "var(--nb-mono)", fontSize: 11, color: "var(--nb-muted)", marginTop: 6 }}>
                  Start a shift or send a quick log →
                </div>
              </div>
            ) : op.history.map((m, i) => <Bubble key={i} msg={m} opColor={"var(--nb-bg-alt)"} />)}
          </div>

          {/* Input */}
          <div style={{
            padding: "12px 18px",
            borderTop: "var(--nb-border-thick)",
            background: "var(--nb-paper)",
            display: "flex", gap: 10,
          }}>
            <input
              className="nb-input"
              style={{ flex: 1 }}
              placeholder={`Type as ${op.name.split(" ")[0]}...`}
              value={draft}
              onChange={e => setDraft(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter") send(); }}
            />
            <button className="nb-btn ink" onClick={() => send()}>Send →</button>
          </div>
        </div>
      </div>
    </div>
  );
}

window.OperatorSandbox = OperatorSandbox;
